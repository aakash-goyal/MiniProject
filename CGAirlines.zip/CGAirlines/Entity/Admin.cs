﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    
        public class Admin
        {
            public int AdminId { get; set; } = 1023;

            public string AdminName { get; set; } = "admin";

            public string Password { get; set; } = "admin@123";
        }
    
}
