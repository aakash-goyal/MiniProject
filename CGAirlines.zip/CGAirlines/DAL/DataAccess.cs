﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using Exceptions;

namespace DAL
{
    public class DataAccess
    {
        
        SqlConnection con = new SqlConnection("Data Source = ndamssql\\sqlilearn; Initial Catalog = Training_5Sep18_Blr; User ID = sqluser; Password=sqluser");
        SqlCommand cmd = new SqlCommand();
        Training_5Sep18_BlrEntities db = new Training_5Sep18_BlrEntities();
        Admin obj1 = new Admin();
        User obj2 = new User();
        public int AdminLogin(Admin aobj)
        {
            if ((aobj.AdminId == obj1.AdminId) && (aobj.Password.Equals(obj1.Password)))
            {
                return 1;
            }
            return 0;
        }
        public int UserHome(User uobj)
        {
            User obj = db.Users.Find(uobj.Id);
            if ((obj.Id == uobj.Id) && (obj.Password.Equals(uobj.Password)))
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        public int AddUser(User obj)
        {
            db.Users.Add(obj);
            db.SaveChanges();
            return obj.Id;
        }
        public DataTable GetDestination()
        {
            DataTable dt = null;
            cmd.CommandText = "CGA.uspGetDestination_Flights";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dt = new DataTable();
                dt.Load(dr);
            }
            con.Close();
            return dt;
        }
        public DataTable GetOrigin()
        {
            DataTable dt = null;
            cmd.CommandText = "CGA.uspGetOrigin_Flights";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dt = new DataTable();
                dt.Load(dr);
            }
            return dt;
        }
    }
}
