﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CGAirlines
{
    /// <summary>
    /// Interaction logic for RevenueGenerate.xaml
    /// </summary>
    public partial class RevenueGenerate : Window
    {
        public RevenueGenerate()
        {
            InitializeComponent();
        }

        private void btnTotalRevenue_Click(object sender, RoutedEventArgs e)
        {
            gridId.Visibility = Visibility.Collapsed;
            gridRevenue.Visibility = Visibility.Collapsed;
            gridTotal.Visibility = Visibility.Visible;
        }

        private void btnFlightRevenue_Click(object sender, RoutedEventArgs e)
        {
            gridId.Visibility = Visibility.Visible;
            gridTotal.Visibility = Visibility.Collapsed;
        }

        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            MainWindow home = new MainWindow();
            home.Show();
            this.Close();
        }

        private void btnHomePage_Click(object sender, RoutedEventArgs e)
        {
            AdminLogin homePage = new AdminLogin();
            homePage.Show();
            this.Close();
        }

        private void ddlId_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            gridRevenue.Visibility = Visibility.Visible;
        }

        private void txtHome_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            MainWindow home = new MainWindow();
            home.Show();
            this.Close();
        }
    }

}
