﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CGAirlines
{
    /// <summary>
    /// Interaction logic for BookTicket.xaml
    /// </summary>
    public partial class BookTicket : Window
    {
        int Id;

        public BookTicket(int id)
        {
            InitializeComponent();
            Id = id;
        }

        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            MainWindow home = new MainWindow();
            home.Show();
            this.Close();
        }

        private void btnHomePage_Click(object sender, RoutedEventArgs e)
        {
            UserHome login = new UserHome();
            login.Show();
            this.Close();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            FlightList flights = new FlightList();
            flights.Show();
            this.Close();
        }

        private void btnBook_Click(object sender, RoutedEventArgs e)
        {

        }

        private void txtHome_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            MainWindow home = new MainWindow();
            home.Show();
            this.Close();
        }
    }

}
