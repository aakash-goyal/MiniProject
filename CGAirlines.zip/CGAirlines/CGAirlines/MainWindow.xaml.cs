﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BLL;
using Entity;
using Exceptions;
using DAL;

namespace CGAirlines
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        BusinessLogic balObj = new BusinessLogic();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string type = "";
            if (Admin.IsChecked == true)
                type = Admin.Content.ToString();
            else if (User.IsChecked == true)
                type = User.Content.ToString();
            else
                MessageBox.Show("Select Login Type");
            if (type.Equals("admin"))
            {
                Admin adminObj = new Admin
                {
                    AdminId = int.Parse(Id.Text),
                    Password = Password.Password.ToString(),
                };
                int res = balObj.AdminLogin(adminObj);
                if (res == 1)
                {
                    AdminLogin winObj = new AdminLogin();
                    winObj.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Wrong Admin Credentials");
                }
            }
            else if (type.Equals("user"))
            {
                User userObj = new User
                {
                    Id = int.Parse(Id.Text),
                    Password = Password.Password.ToString(),
                };
                //int id = int.Parse(UserId.Text);
                //string pass = Password.Text;
                int res = balObj.UserHome(userObj);

                if (res == 1)
                {
                    UserHome winObj = new UserHome(userObj.Id);
                    winObj.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Wrong Admin Credentials");
                }
            }
        }

        private void btnSignup_Click(object sender, EventArgs e)
        {
            UserSignUp signUpObj = new UserSignUp();
            signUpObj.Show();
            this.Close();

        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {

            DataTable dt1 = balObj.GetDestination();
            if (dt1 != null)
            {
                cmbDestination.ItemsSource = dt1.DefaultView;
                cmbDestination.DisplayMemberPath = "Destination";
                cmbDestination.SelectedValuePath = "Destination";
            }

            DataTable dt2 = balObj.GetOrigin();
            if (dt2 != null)
            {
                cmbOrigin.ItemsSource = dt2.DefaultView;
                cmbOrigin.DisplayMemberPath = "Origin";
                cmbOrigin.SelectedValuePath = "Origin";
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            string dest = cmbDestination.SelectedValue.ToString();
            string org = cmbOrigin.SelectedValue.ToString();
            FlightList flights = new FlightList(dest, org);
            flights.Show();
            this.Close();
        }
    }
}
