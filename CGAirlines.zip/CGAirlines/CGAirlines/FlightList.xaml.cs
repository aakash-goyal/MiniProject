﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CGAirlines
{
    /// <summary>
    /// Interaction logic for FlightList.xaml
    /// </summary>
   
        public partial class FlightList : Window
        {
            string Destination, Origin;
            int Id;

            public FlightList()
            {
                InitializeComponent();
                Id = 0;
            }
            public FlightList(int id)
            {
                InitializeComponent();
                Id = id;
            }

            public FlightList(string destination, string origin)
            {
                InitializeComponent();
                Destination = destination;
                Origin = origin;
            }

            private void txtHome_PreviewMouseDown(object sender, MouseButtonEventArgs e)
            {
                MainWindow home = new MainWindow();
                home.Show();
                this.Close();
            }
        }
    }

