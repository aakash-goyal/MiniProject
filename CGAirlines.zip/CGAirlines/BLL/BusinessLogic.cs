﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using Entity;
using Exceptions;

namespace BLL
{
    public class BusinessLogic
    
        {
        DataAccess dalObj = new DataAccess();
        public int AdminLogin(Admin obj)
        {
            int res = dalObj.AdminLogin(obj);
            return res;
        }
        public int UserHome(User Obj)
        {
            int res = dalObj.UserHome(Obj);
            return res;
        }
        public int AddUser(User Obj)
        {
            int id = dalObj.AddUser(Obj);
            return id;
        }
        public DataTable GetDestination()
        {
            return dalObj.GetDestination();
        }
        public DataTable GetOrigin()
        {
            return dalObj.GetOrigin();
        }
    }
}

